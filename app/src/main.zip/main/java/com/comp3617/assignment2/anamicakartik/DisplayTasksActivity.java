package com.comp3617.assignment2.anamicakartik;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

public class DisplayTasksActivity extends AppCompatActivity {

    private ListView lvTasks;
    private TaskListAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_tasks);
        displayList();
    }

    public void displayList(){
        lvTasks = (ListView)findViewById(R.id.lvTasks);
        adapter = new TaskListAdapter(this, TaskList.getInstance().getTaskList());
        lvTasks.setAdapter(adapter);
        lvTasks.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Task taskSelected = (Task) lvTasks.getAdapter().getItem(position);
                taskSelected.setMyPositionInList(position);
                Intent editIntent = new Intent(DisplayTasksActivity.this, ActionActivity.class);
                editIntent.putExtra("selectedTaskItem", taskSelected);
                startActivity(editIntent);
            }
        });


        lvTasks.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {

            public boolean onItemLongClick(AdapterView<?> arg0, View v,
                                           int index, long arg3) {
                alertMessage(index);
                return true;
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.actionbar, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch(item.getItemId()) {
            case R.id.action_create:
                Intent addIntent = new Intent(DisplayTasksActivity.this, ActionActivity.class);
                startActivity(addIntent);
                break;
            default:
                return super.onOptionsItemSelected(item);
        }
        return true;
    }

    public void alertMessage(int index) {
        final int deletePos = index;
        DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                switch (which) {
                    case DialogInterface.BUTTON_POSITIVE:

                        TaskList.getInstance().deleteTask(deletePos);
                        adapter.notifyDataSetChanged();
                        break;

                    case DialogInterface.BUTTON_NEGATIVE:
                        break;
                }
            }
        };

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Are you sure to delete this item?")
                .setPositiveButton("Yes", dialogClickListener)
                .setNegativeButton("No", dialogClickListener).show();
    }
}

