package com.comp3617.assignment2.anamicakartik;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by jkart on 2016-06-22.
 */
public class TaskList {

    private static TaskList mInstance ;
    private List<Task> tasks = null;

    public static TaskList getInstance() {

        if(mInstance == null){
            synchronized (TaskList.class){
                mInstance = new TaskList();
            }
        }
        return mInstance;
    }

    public List<Task> getTaskList(){

        return tasks;
    }

    public void editTask(Task eTask,int pos){
        tasks.remove(pos);
        tasks.add(pos,eTask);
    }

    public void addTask(Task pTask){
        tasks.add(pTask);
    }

    public void deleteTask(int pos){
        tasks.remove(pos);
    }

    private TaskList() {
        tasks = new ArrayList<Task>();

        Task tk1 = new Task();
        tk1.setTitle("Assignment 2");
        tk1.setDescription("Assignment 2 not completed");
        tk1.setStatus("Pending");
        tk1.setCategory("Work");
        tk1.setPriority("High");
        tk1.setImageResource(R.drawable.work);
        tk1.setMyPositionInList(0);
        tk1.setAddress("7488 Byrnepark Walk");
        //tk1.setAddressLocation();
        tasks.add(tk1);
    }
}
